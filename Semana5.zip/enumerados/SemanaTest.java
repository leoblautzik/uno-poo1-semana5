package enumerados;

public class SemanaTest {

	public static void main(String[] args) {
		
		Semana diaDeHoy = Semana.LUNES; 
		Semana mañana = Semana.MARTES; 
		System.out.println(diaDeHoy);
		System.out.println(mañana);
	
		
	}

}
